package pao;


public interface ClusterMethod {

	public void setData(NumberRow numRow, UnitRow data);
	public void analyzeData();
	public ClusterRow getClusterTree();
}
